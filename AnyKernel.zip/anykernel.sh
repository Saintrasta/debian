# AnyKernel2 Ramdisk Mod Script
# osm0sis @ xda-developers
# Thanks to Mihran thalhath, coz i took this script from his no name kernel.
# Thanks to Kaizen, for let me use his Ramdisk script

## AnyKernel setup
# begin properties
properties() {
kernel.string=HAHAHA NGENTOOD
do.devicecheck=1
do.modules=0
do.cleanup=1
do.cleanuponabort=0
device.name1=redmi4a
device.name2=rolex
} # end properties

# shell variables
block=/dev/block/bootdevice/by-name/boot;
is_slot_device=0;
ramdisk_compression=auto;

## AnyKernel methods (DO NOT CHANGE)
# import patching functions/variables - see for reference
. /tmp/anykernel/tools/ak2-core.sh;


## AnyKernel file attributes
# set permissions/ownership for included ramdisk files
chmod -R 750 $ramdisk/*;
chown -R root:root $ramdisk/*;
# Ngntd messages
ui_print "                                               ";
ui_print "           _   _  ____ _   _ _____ ____        ";
ui_print "          | \ | |/ ___| \ | |_   _|  _ \       ";
ui_print "          |  \| | |  _|  \| | | | | | | |      ";
ui_print "          | |\  | |_| | |\  | | | | |_| |      ";
ui_print "          |_| \_|\____|_| \_| |_| |____/       ";
ui_print "                    K E R N E L                ";
ui_print "                      UNIFIED                  ";
ui_print "                Ahmad Thoriq Najahi            ";
ui_print "                                               ";
## AnyKernel install
dump_boot;
# begin ramdisk changes 
# init.rc
insert_line init.rc "init.spectrum.rc" after "import /init.spectrum.rc";

# end ramdisk changes

write_boot;

## end install

